package com.example.memeify

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TakePictureActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_take_picture)
    }
}
